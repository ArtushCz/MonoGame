﻿using Microsoft.Xna.Framework.Input;

namespace TestGame
{
    public class GameMouse
    {
        public MouseState state;
    }
}